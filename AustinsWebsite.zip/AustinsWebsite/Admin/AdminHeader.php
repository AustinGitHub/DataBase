<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


  <body bgcolor="grey">


<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 300px;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    padding-top: 20px;
}

.sidenav a, .dropdown-btn {
    padding: 6px 8px 6px 16px;
    text-decoration: none;
    font-size: 20px;
    color: #818181;
    display: block;
    border: none;
    background: none;
    width: 100%;
    text-align: left;
    cursor: pointer;
    outline: none;
}

.sidenav a:hover, .dropdown-btn:hover {
    color: #f1f1f1;
}

.main {
    margin-left: 300px; 
    font-size: 20px;
    padding: 0px 10px;
}

.active {
    background-color: green;
    color: white;
}


.dropdown-container {
    display: none;
    background-color: #262626;
    padding-left: 8px;
}

.fa-caret-down {
    float: right;
    padding-right: 8px;
}


@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
    .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
<!-- Admin Panel Menu -->
<div class="sidenav">
  <button class="dropdown-btn">Races Management 
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">Upcoming Races </a>
    <a href="#">Archived Races </a>
  </div>
    <button class="dropdown-btn">Games Management 
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">Manage Game </a>
    <a href="#">Create Game </a>
    <a href="#">Game Rule </a>
  </div>
  
    <button class="dropdown-btn">Users Management
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="ManageUser.php">Manage User </a>
    <a href="#">User Manual Entry </a>
    <a href="#">User Manual Pick/Result Update </a>
    <a href="#">Remove Users From Game </a>
  </div>
  
      <button class="dropdown-btn">Lifeline Management
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">Lifeline Games Report </a>
    <a href="#">User Manual Lifeline Entry </a>
  </div>
   <button class="dropdown-btn">Reports Management
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">Daily New Users Report </a>
    <a href="#">Daily Games Report </a>
    <a href="#">All Games Users Entry Report</a>
    <a href="#">All Games Users Pick Report</a>
  </div>

  <button class="dropdown-btn">Entry Management
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="AddEntry.php">Add Entry</a>
    <a href="#">Manage Entries </a>
  </div>
  
    <button class="dropdown-btn">Result Management
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">Race Result Update</a>
  </div>
  
     <button class="dropdown-btn">Account Management
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
  <a href="AdminHeader.php">Home</a>
  <a href="ResetPassword.php">Change Password</a>
  <a href="Admin.php" action="../AdminDbh/logout.admin.php" method="POST">Logout</a>
  </div>
</div>
  
  



<script>

var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>

</body>
</html> 
