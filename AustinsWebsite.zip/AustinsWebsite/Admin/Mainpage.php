<?php 
session_start();

if (isset($_SESSION['u_password'])) {
	include '../AdminDbh/timeout.admin.php';
} else {
	header("Location: ../Admin/Mainpage.php");
}

?>

<?php include 'AdminHeader.php' ?>


<body bgcolor="grey">
	<div style="display: flex;justify-content: center;align-items:center;">

		
		
</div>

</html>