<?php 
session_start();
?>
<?php include 'AdminHeader.php' ?>
<?php include '../Includes/dbh.inc.php' ?>
=

	<body bgcolor="grey">
		<div class="main">
	<?php

$ch = curl_init ("http://www.drf.com/race-entries/track/SAR/country/USA/date/07-27-2018");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec($ch);

preg_match('#<table[^>]*>(.+?)</table>#is', $page, $matches);
foreach ($matches as &$match) {
    $match = $match;
}
echo '<table>';
    echo $matches[1];
echo '</table>';


?>  