<?php 
session_start();
?>
<?php include 'AdminHeader.php' ?>
<?php include '../includes/dbh.inc.php' ?>
<script src="tabletocsv.js"></script>

	<body bgcolor="grey">
		<div class="main">
			<style>
table, th, td {
    border: 1px solid black;

}
table {
	border-spacing: 15px;
}
.download {
	height: 100px;
	width: 200px;
	font-size: 20px;
	background-color: red;
	border-color: red;
}
</style>

<center> <button class="download" onclick="exportTableToCSV('Users.csv')">Download</button></center><br/>
<?php 



$sql = "SELECT * FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Address</th><th>Phone Number</th><th> Action </th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["user_id"]. "</td><td>" . $row["user_first"]. " " . $row["user_last"].  "  <td>  " . $row["user_uid"]. " </td><td>" . $row["user_email"]. " </td><td>" . $row["user_address"]. " </td><td>" . $row["user_phone"]. "<td> <center><button onclick=\"location.href='EditUser.php'\"> Edit User </button>". "</td></tr>";
        
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?> 
