<?php 
session_start();
?>
<?php include 'AdminHeader.php' ?>



	<body bgcolor="grey">
		<div class="main">
	<h2>Reset Password</h2>
	<form class="signup-form" action="../AdminDbh/resetpwd.admin.php" method="POST">
			<input type="text" name="username" placeholder="Username"><br/>
		<input type="password" name="newpwd" placeholder="New Password"><br/>
		<button type="submit" name="submit">Reset Password</button>
	</form>
<br/>
	 	 </div>
	

