<?php 

if(isset($_POST['submit'])) {

	include_once 'dbh.inc.php';

	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$pwd = mysqli_real_escape_string($conn, $_POST['newpwd']);

	// Error Handlers
	// Check if inputs are empty
	if(empty($email) || empty($pwd)) {
		header("Location: ../resetpwd.php?resetpwd=empty");
		exit();
	} else {
		$sql = "SELECT * FROM users WHERE user_email='$email'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck == false) {
			header("Location: ../resetpwd.php?resetpwd=error");
			exit();
		} else {
			if($row = mysqli_fetch_assoc($result)) {
				
				$hashedPwdCheck = '$pwd';
				if($hashedPwdCheck == false) {
					header("Location: ../resetpwd.php?resetpwd=error1");
					exit();
				} elseif($hashedPwdCheck == true) {
					// Log in the user here
					$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
					$sql = "UPDATE users SET user_email='$email', user_pwd= '$hashedPwd' WHERE user_email='$email';";
					mysqli_query($conn, $sql);
					header("Location: ../resetpwd.php?resetpwd=success");
					exit();
				}

			}
		}
	}
	
}	else {
		header("Location: ../index.php?login=error");
		exit();
}