<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "user";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);