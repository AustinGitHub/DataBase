<?php include_once 'header.php';
?>

<section class="main-container"> 
	<div class="main-wrapper">
	<h2>Reset Password</h2>
	<form class="signup-form" action="includes/resetpwd.inc.php" method="POST">
		Email: <input type="text"  name="email" placeholder="Email"> <br/>
		New Password: <input type="password" name="newpwd" placeholder="New Password">
		<button type="submit" name="submit">Reset Password</button>
	</form>
<br/>
	 	 
	 </div>
</section>

<?php 
	include_once 'footer.php';
	?>