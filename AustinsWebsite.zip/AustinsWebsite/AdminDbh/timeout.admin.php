
<?php 
include 'dbh.admin.php';

 if(time() - $_SESSION['timestamp'] > 900) { //subtract new timestamp from the old one
    echo"<script>alert('15 Minutes over!');</script>";
    unset($_SESSION['u_username'], $_SESSION['u_password'], $_SESSION['timestamp']);
    $_SESSION['logged_in'] = false;
    session_destroy();
    header("Location: ../Admin/Admin.php");
    exit;
} else {
    $_SESSION['timestamp'] = time(); //set new timestamp
}
?>