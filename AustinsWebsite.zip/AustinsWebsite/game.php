<?php include_once 'header.php';
?>

<!DOCTYPE html> 
<html> 
<head>
	<title>Game </title>
	<link rel="stylesheet" type="text/css" href="style/sheets.css">
</head>
<body>
<p> Hello </p>
	<!-- This is where the game would go -->

<section> 

</section>

</body>