<?php include_once 'header.php';
?>

<link rel="stylesheet" type="text/css" href="styles/sheets.css">
<section class="main-container"> 
	<div class="main-wrapper">
	<h2>Home</h2>

	
	<?php 

		if(isset($_SESSION['u_id'])) {
		echo "You are logged in! <br/>";
		echo "Hello ", $_SESSION['u_uid'];
		echo '    ';
		echo '<br/><br/>
		<div id="1"> </div>





		 ';


}
?>
	 </div>

</section>


<?php 
	include_once 'footer.php';
	?>

	