<?php include '../Admin/AdminHeader.php' ?>
<?php include '../Includes/dbh.inc.php' ?>
<?php include 'EntryDBH.admin.php' ?>

	<div class="main">
<?php 

  if(isset($_POST['submit'])) {
  $Date = $_POST['date'];
  
    $sql = "CREATE TABLE IF NOT EXISTS `$Date` (
`RaceNumber` varchar(256) NOT NULL,
  `Track` varchar(256) NOT NULL,
  `HorseNum` varchar(256) NOT NULL,
  `HorseName` varchar(256) NOT NULL,
  `Odds` varchar(256) NOT NULL,
  `Color` varchar(256) NOT NULL,
  `JockeyName` varchar(256) NOT NULL,
  `TrainerName` varchar(256) NOT NULL
    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8";
    $query2 = mysqli_connect('localhost','root','','Races');   
   
    $z= mysqli_query($query2, $sql) or die("Table already exist.. please try again");
    echo "Your Table ".$Date." is successfully created <br/>";


$RaceNum = $_POST['RaceNum'];

$i=1;




while($i<=$RaceNum){

echo 'Race Number '.$i.' : <br/>
<form method="POST"> 
<input type="text" name="Date" value='.$Date.' readonly>
Number of Horses 
<select name="NumHorse">
	<option value="1"> 1 </option>
	<option value="2"> 2 </option>
	<option value="3"> 3 </option>
	<option value="4"> 4 </option>
	<option value="5"> 5 </option>
	<option value="6"> 6 </option>
	<option value="7"> 7 </option>
	<option value="8"> 8 </option>
	<option value="9"> 9 </option>
	<option value="10"> 10 </option>
	<option value="11"> 11 </option>
	<option value="12"> 12 </option>
	<option value="13"> 13 </option>
	<option value="14"> 14 </option>
	<option value="15"> 15 </option>
	<option value="16"> 16 </option>
	<option value="17"> 17 </option>
	<option value="18"> 18 </option>
	<option value="19"> 19 </option>
	<option value="20"> 20 </option>
	</select>
<button  name="submit2">Submit </button> 
</form>

';

global $NumHorse;
global $HorseNumber;
global $HorseName;

 $i++;

}
}
?> 
<?php



if(isset($_POST['submit2'])) {
	$NumHorse= $_POST["NumHorse"];
	$Date = $_POST["Date"];


for($w = 1; $w <= $NumHorse; $w++){
	echo '
	<form method="POST">
	<b><h2>Horse Info </h2></b><br/>
	Date: <input type="text" value="'.$Date.'" name="Date" readonly> <br/>
	Race Number: <input type="text" name="RaceNum"><br/>
	Track: <input type="text" name="Track"><br/>
	Color: <input type="text" name="Color"><br/>
	Horse Number: <input type="text" name="Num"><br/>
	Horse Name: <input type="text" name="HorseName"><br/>
	Odds: <input type="text" name="Odds"><br/>
	
<br/>
	<b><h2>Jockey</h2></b>
	Full Name:<input type="text" name="Jockey"><br/>

	<b><h2>Trainer</h2></b>
	Full Name:<input type="text" name="Trainer"><br/><br/><br/>
	<button name="Submit3">Submit </button>
	</form>
	
	';
	
		}	


	}
	

		if(isset($_POST['Submit3'])) {
			
			
			
			$Date = $_POST['Date'];

			// Horse Info 
			$query2 = mysqli_connect('localhost','root','','races');   
			$RaceNumber = mysqli_real_escape_string($query2,$_POST['RaceNum']);
			$Track = mysqli_real_escape_string($query2,$_POST['Track']);
			$Color = mysqli_real_escape_string($query2,$_POST['Color']);
			$Num = mysqli_real_escape_string($query2,$_POST['Num']);
			$HorseName = mysqli_real_escape_string($query2,$_POST['HorseName']);
			$Odds = mysqli_real_escape_string($query2,$_POST['Odds']);
			
			// Jockey Info 

			$Jockey = mysqli_real_escape_string($query2,$_POST['Jockey']);
			$Trainer = mysqli_real_escape_string($query2,$_POST['Trainer']);
			

$sql = "INSERT INTO `$Date` (RaceNumber,Track,HorseNum,HorseName,Odds,Color,JockeyName,TrainerName) VALUES ('$RaceNumber','$Track','$Color','$Num','$HorseName','$Odds','$Jockey','$Trainer');";

 
				if ($query2->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $query2->error;
}

			}


	



?>