<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "admin";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);


