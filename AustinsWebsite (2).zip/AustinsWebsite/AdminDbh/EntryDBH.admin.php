<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";


$conn2 = new mysqli($dbServername,$dbUsername,$dbPassword);