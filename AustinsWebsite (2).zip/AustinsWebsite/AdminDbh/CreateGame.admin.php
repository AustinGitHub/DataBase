<?php 


  if(isset($_POST['submit'])) {
     $conn = mysqli_connect('localhost','root','','games');   
 $Dates = mysqli_real_escape_string($conn,$_POST['dates']);
   $Gametype = mysqli_real_escape_string($conn,$_POST['GameType']);
   $Subtype = mysqli_real_escape_string($conn,$_POST['SubType']);
   $Gamename = mysqli_real_escape_string($conn,$_POST['GameName']);
  
   $Feetype = mysqli_real_escape_string($conn,$_POST['FeeType']);
   $Entryfee = mysqli_real_escape_string($conn,$_POST['EntryFee']);
   $Minplayers = mysqli_real_escape_string($conn,$_POST['MinPlayers']);
   $Maxplayers = mysqli_real_escape_string($conn,$_POST['MaxPlayers']);
   $Maxentries = mysqli_real_escape_string($conn,$_POST['MaxEntries']);
   $Detailedprize = mysqli_real_escape_string($conn,$_POST['DetailedPrize']);
   $Gametype2 = mysqli_real_escape_string($conn,$_POST['GameType2']);

   if($Minplayers > $Maxplayers) {
    header("Location: ../Admin/CreateGame.php?Create=error");
   }

   if($Gametype2 == 'Normal Game') {
    echo '';
   } elseif($Gametype2 == 'PlaceHolder') {
      echo '<form method="POST"><input type="date" name="PlaceHolderDate"></form>';
   }
   $PlaceHolderDate = mysqli_real_escape_string($Conn,$_POST['PlaceHolderDate']);


    $sql = "INSERT INTO games (Dates,GameType,SubType,GameName,FeeType,EntryFee,MinPlayers,MaxPlayers,MaxEntries,PrizeDetails,GameType2,PlaceHolderDate) VALUES ('$Dates','$Gametype','$Subtype','$Gamename','$Feetype','$Entryfee','$Minplayers','$Maxplayers','$Maxentries','$Detailedprize','$Gametype2','$PlaceHolderDate');";

        if ($conn->query($sql) === TRUE) {
   
    header("Location: ../Admin/ManageGame.php?Create=Success");
    exit();
} else {
   
     header("Location: ../Admin/CreateGame.php?Create=error");
     exit();
}
   }
  ?>