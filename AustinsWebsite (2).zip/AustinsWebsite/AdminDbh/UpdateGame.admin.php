<?php 

if(isset($_POST['submit1'])) {



	$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "games";
    $conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);

    $Id = mysqli_real_escape_string($conn,$_POST['id']);
	$Dates = mysqli_real_escape_string($conn,$_POST['dates']);
   $Gametype = mysqli_real_escape_string($conn,$_POST['GameType']);
   $Subtype = mysqli_real_escape_string($conn,$_POST['SubType']);
   $Gamename = mysqli_real_escape_string($conn,$_POST['GameName']);
  
   $Feetype = mysqli_real_escape_string($conn,$_POST['FeeType']);
   $Entryfee = mysqli_real_escape_string($conn,$_POST['EntryFee']);
   $Minplayers = mysqli_real_escape_string($conn,$_POST['MinPlayers']);
   $Maxplayers = mysqli_real_escape_string($conn,$_POST['MaxPlayers']);
   $Maxentries = mysqli_real_escape_string($conn,$_POST['MaxEntries']);
   $Detailedprize = mysqli_real_escape_string($conn,$_POST['DetailedPrize']);
   $Gametype2 = mysqli_real_escape_string($conn,$_POST['GameType2']);
   $PlaceHolderDate = mysqli_real_escape_string($conn,$_POST['PlaceHolderDate']);
	$NewGameName = mysqli_real_escape_string($conn, $_POST['NewGameName']);



	// Error Handlers
	// Check if inputs are empty
	if(empty($Dates) ) {
		header("Location: ../Admin/EditGame.php?input=empty");
		exit();
	} else {
		$sql = "SELECT * FROM games WHERE Id='$Id'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck == false) {
			header("Location: ../Admin/EditGame.php?EditGame=error");
			exit();
		} else {
			
			if($row = mysqli_fetch_assoc($result)) {
				
		

					$sql = "UPDATE games SET GameName ='$NewGameName', Dates = '$Dates',GameType = '$Gametype',SubType = '$Subtype', Feetype = '$Feetype', Minplayers = '$Minplayers', Maxplayers = '$Maxplayers', MaxEntries = '$Maxentries', PrizeDetails = '$Detailedprize', GameType2 = '$Gametype2',PlaceHolderDate = '$PlaceHolderDate'  WHERE Id='$Id';";
					mysqli_query($conn, $sql);
					header("Location: ../Admin/ManageGame.php?Change=Success");
					exit();
				}

			}
		}
	}
	
	else {
		header("Location: ../Admin/ManageGame.php?Game=error");
		exit();
}