<?php 

if(isset($_POST['submit'])) {

	include_once '../includes/dbh.inc.php';

	$user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
	$first = mysqli_real_escape_string($conn, $_POST['first']);
	$last = mysqli_real_escape_string($conn, $_POST['last']);
	$uid = mysqli_real_escape_string($conn, $_POST['uid']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$phoneNum = mysqli_real_escape_string($conn, $_POST['phone']);	
	$address = mysqli_real_escape_string($conn, $_POST['address']);

	$Newfirst = mysqli_real_escape_string($conn, $_POST['Newfirst']);



	// Error Handlers
	// Check if inputs are empty
	if(empty($Newfirst) || empty($last) || empty($uid) || empty($email)  || empty($address) || empty($phoneNum)) {
		header("Location: ../Admin/EditUser.php?input=empty");
		exit();
	} else {
		$sql = "SELECT * FROM users WHERE user_id='$user_id'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck == false) {
			header("Location: ../Admin/EditUser.php?UpdateUser=error");
			exit();
		} else {
			
			if($row = mysqli_fetch_assoc($result)) {
				
		

					$sql = "UPDATE users SET user_first='$Newfirst', user_last='$last', user_uid='$uid', user_email='$email', user_phone='$phoneNum', user_address='$address' WHERE user_id='$user_id';";
					mysqli_query($conn, $sql);
					header("Location: ../Admin/ManageUser.php?Change=Success");
					exit();
				}

			}
		}
	}
	
	else {
		header("Location: ../Admin/ManageUser.php?login=error");
		exit();
}