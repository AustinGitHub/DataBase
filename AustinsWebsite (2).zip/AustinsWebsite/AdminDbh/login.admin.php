<?php

session_start();


if (isset($_POST['submit'])) {

	include 'dbh.admin.php';
	$uid = mysqli_real_escape_string($conn, $_POST['uid']);
	$pwd = mysqli_real_escape_string($conn, $_POST['pwd']);

	// Error Handlers
	// Check if inputs are empty
	if(empty($uid) || empty($pwd)) {
		header("Location: ../Admin/Admin.php?login=empty");
		exit();
	} else {
		$sql = "SELECT * FROM admin WHERE username='$uid'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck <1) {
			header("Location: ../Admin/Admin.php?login=errorj");
			exit();
			
	} else {
			if($row = mysqli_fetch_assoc($result)) {
				// De-hashing the password
				$hashedPwdCheck = password_verify($pwd, $row['password']);
				if($hashedPwdCheck == false) {
					header("Location: ../Admin/Admin.php?login=error1");
					echo("Invalid username or password");
					exit();

				} elseif($hashedPwdCheck == true) {
					// Log in the user here
					$_SESSION['u_username'] = $row['username'];
					$_SESSION['u_password'] = $row['password'];
					$_SESSION['timestamp'] = time();
					
					header("Location: ../Admin/Mainpage.php?login=success");
					exit();


					
				}
				
			}
			
		}
	}
}

	else {
		header("Location: ../Admin/Admin.php?login=error");
		exit();
}