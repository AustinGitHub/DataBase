
<body bgcolor="grey">
	<div style="display: flex;justify-content: center;align-items:center;">
<?php 

if(isset($_POST['submit'])) {
	include_once 'dbh.admin.php';


	$uid = mysqli_real_escape_string($conn, $_POST['username']);
	$pwd = mysqli_real_escape_string($conn, $_POST['newpwd']);

	// Error Handlers
	// Check if inputs are empty
	if(empty($pwd)) {
		header("Location: ../Admin/ResetPassword.php?resetpwd=empty");
		exit();
	} else {
		$sql = "SELECT * FROM admin WHERE username ='$uid'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck == false) {
			header("Location: ../Admin/ResetPassword.php?resetpwd=error");
			exit();
		} else {
			if($row = mysqli_fetch_assoc($result)) {
				
				$hashedPwdCheck = '$pwd';
				if($hashedPwdCheck == false) {
					header("Location: ../Admin/ResetPassword.php?resetpwd=error1");
					exit();
				} elseif($hashedPwdCheck == true) {
					// Log in the user here
					$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
					$sql = "UPDATE admin SET username='$uid', password= '$hashedPwd' WHERE username='$uid';";
					mysqli_query($conn, $sql);
					header("Location: ../Admin/ResetPassword.php?resetpwd=Success");
					exit();
				}

			}
		}
	}
	
}	else {
		header("Location: ../Admin/ResetPassword.php?resetpwd=error2");
		exit();
}
		
		
