<?php include_once 'header.php';
?>

<!DOCTYPE html> 
<html> 
<head>
	<title> Home </title>
	<link rel="stylesheet" type="text/css" href="style/sheets.css">
</head>
<body>

	<!-- This is where website image would go -->

<section> 

</section>

</body>