<?php include_once 'header.php';
?>

<link type="text/css" rel="stylesheet" href="styles/sheets.css" >
<section class="main-container"> 
	<div class="main-wrapper">
	<h2>Signup</h2>
	
	<form class="signup-form" action="includes/signup.inc.php" method="POST">
	<form class="signup-form" action="includes/signupverify.inc.php" method="POST">
		Name: <input type="text" name="first" placeholder="Firstname">
		Last Name: <input type="text" name="last" placeholder="Lastname">
		Email: <input type="text" name="email" placeholder="E-mail">
		Address: <input type="text" name="address" placeholder="Address" required="true">
		Phone: <input type="text" name="phone" placeholder="Phone Number">
		Username: <input type="text" name="uid" placeholder="Username">
		Password: <input type="password" name="pwd" placeholder="Password"> <br></br>
		<button type="submit" name="submit">Sign up</button>
	</form>
</form>
<br/>
	<h1><center>	<a href="resetpwd.php">Reset Password </a>
	 </div>
</section>

<?php 
	include_once 'footer.php';
	?>