<?php 


if(isset($_POST['submit'])) {

	include_once 'dbh.inc.php';

	$first = mysqli_real_escape_string($conn, $_POST['first']);
	$last = mysqli_real_escape_string($conn, $_POST['last']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$uid = mysqli_real_escape_string($conn, $_POST['uid']);
	$pwd = mysqli_real_escape_string($conn, $_POST['pwd']);
	$phoneNum = mysqli_real_escape_string($conn, $_POST['phone']);
	$address = mysqli_real_escape_string($conn, $_POST['address']);
	
	
	
	

	

	if(empty($first) || empty($last))  {
	header("Location: ../signup.php?signup=empty1");
	
	exit();	
	} else {
		// Check if input characters are valid
		if(!preg_match("/^[-a-zA-Z]*$/", $first) || !preg_match("/^[-a-zA-Z]*$/", $last)) {
			header("Location: ../signup.php?signup=invalid");

			exit();
		} else {
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				header("Location: ../signup.php?signup=email");
			exit();
			} else {
				
				$sql = "SELECT * FROM users WHERE user_email = '$email'"; // checking to see if input is same as database
				$result = mysqli_query($conn, $sql);
				$yes = mysqli_num_rows($result); // result being 1 

				if($yes >0) { // if result is greater than 1 
					header("Location: ../signup.php?signup=EmailTaken");


					exit();
				} else {
					// Hashing the password 
					$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

					


					// Insert the user into the database
					$sql = "INSERT INTO users (user_first,user_last,user_email,user_uid,user_pwd,user_phone,user_address) VALUES ('$first','$last','$email','$uid','$hashedPwd','$phoneNum','$address');";
					mysqli_query($conn, $sql);

					
		


					include'signupverify.inc.php';
					session_start();
					
					exit();
				}
			}
		}
	}


} else {
	header("Location: ../signup.php");
	exit();
}