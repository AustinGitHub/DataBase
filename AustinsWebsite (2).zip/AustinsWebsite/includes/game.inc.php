<?php 

if(isset($_POST['submit'])) {
session_start();
	header("Location: ../game.php");

}