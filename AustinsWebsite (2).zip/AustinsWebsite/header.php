<?php 
session_start();
?>
<!DOCTYPE html> 
<html> 
<head>
	
	<link type="text/css" rel="stylesheet" href="styles/sheets.css" >
	
</head>

<body>

	<header>
		<nav>
			<div class="main-wrapper">
				<ul> 
					<li><button class="home-button" onclick="window.location.href='index.php'">Home</a></li></button>
				
				</ul>

				<div class="nav-login">
					<?php 
					if (isset($_SESSION['u_uid'])) {
						echo '
						<form action="includes/game.inc.php" method="POST" class="game">
						<button type="submit" name="submit"> Game </button> </form>';

						echo '<form  action="includes/logout.inc.php" method="POST">
						<button type="submit" name="submit">Logout </button></form>';
						
					
					} else {
						echo '<form  action="includes/login.inc.php" method="POST">
						<input type="text" name="uid" placeholder="Username">
						<input type="password" name="pwd" placeholder="Password">
						<button type="submit"   name="submit">Login</button></form>
						<form action="signup.php">
					 <button type="submit">Sign up</button></form>';
					}

						?>

					
				</div>	
				
			</div>
			
		</nav>

	</header>
