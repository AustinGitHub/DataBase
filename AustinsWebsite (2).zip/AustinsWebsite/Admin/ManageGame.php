<?php 
session_start();
?>
<?php include 'AdminHeader.php' ?>

	<body bgcolor="grey">
		<div class="main">
			<style>
table, th, td {
    border: 1px solid black;

}
table {
	border-spacing: 15px;
}
</style>


<?php 



if(isset($_POST['search'])) {
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "games";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
} else {
	$query = "SELECT * FROM 'games'";
	$search_result = filterTable($query);


} function filterTable($query) {
	$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "games";
	$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
	$filter_Result = mysqli_query($conn,$query);
	return $filter_Result;
}
	


?>
<?php 


$results_per_page = 10;

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "games";
	$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
$start_from = ($page-1) * $results_per_page;
$sql = "SELECT * FROM games"." ORDER BY id ASC LIMIT $start_from, ".$results_per_page;
$result = $conn->query($sql) or die($conn->error);

if ($result->num_rows > 0) {
    echo "<br/><table><tr><th>Id</th><th>Name of Contest</th><th>Date</th><th>Type of Game</th><th>Min. Players</th><th>Current Entries</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
    	$Id = $row["Id"];
    	$Id2 = $row["Id"];
        echo "<form method='POST' action='EditGame.php'>
       <tr><td>" . $row["Id"]. "</td><td>" . $row["GameName"].  "  <td>  " . $row["Dates"]. " </td><td>" . $row["GameType"]. " </td><td>" . $row["MinPlayers"]. " </td><td>" . $row["CurrEntries"]. "<td> <center><button name='button' value='$Id' > Edit Game </button>". "</td></tr></form>";
        
    }
    echo "</table>";

} else {
    echo "0 results";
}

?> 

 
 
 
<?php 
$sql = "SELECT COUNT(id) AS total FROM games";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_pages = ceil($row["total"] / $results_per_page); // calculate total pages with results
  
for ($i=1; $i<=$total_pages; $i++) {  // print links for all pages
            echo "<a href='../Admin/ManageGame.php?page=".$i."'";
            if ($i==$page)  echo " class='curPage'";
            echo ">".$i."</a> "; 
}; 
	
?>
