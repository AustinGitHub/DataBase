<html> 
<?php 
session_start();
?>
<?php include 'AdminHeader.php' ?>
<?php include '../Includes/dbh.inc.php' ?>
<?php include '../AdminDbh/EntryDBH.admin.php' ?>
<?php include '../AdminDbh/AddEntry.admin.php' ?>

	<body bgcolor="grey">
		<div class="main">

<form method="POST">
	
	<input type="date" name="date" placeholder="Date"><br/> 
	<select name="RaceNum" id="RaceNum"> 
		<option value="0"> Number of Races </option>
		<option value="1"> 1 </option>
		<option value="2"> 2 </option>
		<option value="3"> 3 </option>
		<option value="4"> 4 </option>
		<option value="5"> 5 </option>
		<option value="6"> 6 </option>
		<option value="7"> 7 </option>
		<option value="8"> 8 </option>
		<option value="9"> 9 </option>
		<option value="10"> 10 </option>
		<option value="11"> 11 </option>
		<option value="12"> 12 </option>
		<option value="13"> 13 </option>
		<option value="14"> 14</option>

	</select><br />
	
	
	<button type="Submit" name="submit"> Submit </button>
</div>
</form>



