<html> 

<?php include 'AdminHeader.php' ?>
	<body bgcolor="grey">
		<div class="main">
 <link rel="stylesheet" href="../styles/bootstrap.min.css">
  <link rel="stylesheet" href="../styles/creategame.css">

 <h1> Create a Game </h1> <br/> 
<form method="POST" action="../AdminDbh/CreateGame.admin.php"> 

<input type="date" name="dates" value="<?php echo date('Y-m-d'); ?>" readonly /><br/>

<div id="one">
  <div class="one">
Type of Game <br/>
<select name="GameType">
  <option> Daily Game </option>

</select>
</div>
</div>

<div id="two">
<div class="two">
Sub Type of Game <br/>
<select name="SubType"> 
  <option> Live Selector </option>
  <option> Locked </option>
</select>
</div>
</div>

<br/><br/>
<div id="three">
  <div class="three"> 
Name of Contest <br/> 
<input type="text" name="GameName" placeholder="Name of Contest" required><br/>
</div>
</div>

<div id="four"> 
  <div class="four">
Fee Type <br/>
<select name="FeeType">
  <option>Dollars</option>
</select>
</div>
</div>

<div id="five"> 
  <div class="five">
Entry Fee <br/>
<input type="text" name="EntryFee" required><br/>
</div>
</div>

<br/><br/>
<div id="six">
  <div class="six"> 
# of Players (minimum and maximum) <br/>
<input type="text" name="MinPlayers" placeholder="Minimum Players" required> <input type="text" name="MaxPlayers" placeholder="Maximum Players" required> <br/>
</div>
</div>

<div id="seven"> 
  <div class="seven"> 
Max Entries Per Player <br/>
<input type="text" name="MaxEntries" placeholder="Max entries per player" required> <br/>
</div>
</div>

<br/><br/>
<div id="eight"> 
  <div class="eight"> 
<label>Detailed Prize Information <br/></label>
<textarea class="eight" style="width: 500px;height:200px;" name="DetailedPrize"></textarea> <br/>
</div>
</div>


<div id="nine">
  <div class="nine">
   <label for="type"> Game Type <br/></label>
    <select name="GameType2" id="type">
     
      <option value="NormalGame"> Normal Game </option>
      <option value="PlaceHolder"> PlaceHolder </option>

    </select>

    
    
</div>
</div>

<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<div id="ten">
  <div class="ten">
<button name="submit"> Create Game </button>
</div>
</div>


</form>
<br/>



</html>