<?php 
session_start();
?>
<?php include 'AdminHeader.php' ?>
<?php include '../includes/dbh.inc.php' ?>
<script src="tabletocsv.js"></script>

	<body bgcolor="grey">
		<div class="main">
			<style>
table, th, td {
    border: 1px solid black;

}
table {
	border-spacing: 15px;
}
.download {
	height: 100px;
	width: 200px;
	font-size: 20px;
	background-color: red;
	border-color: red;
}
</style>

<center> <button class="download" onclick="exportTableToCSV('Users.csv')">Download</button></center><br/>


<?php 
if(isset($_POST['search'])) {

} else {
	$query = "SELECT * FROM 'users'";
	$search_result = filterTable($query);


} function filterTable($query) {
	include '../includes/dbh.inc.php';
	$filter_Result = mysqli_query($connect,$query);
	return $filter_Result;
}
	


?>




<?php 
	include '../includes/dbh.inc.php';

$results_per_page = 10;

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
$start_from = ($page-1) * $results_per_page;
$sql = "SELECT * FROM users"." ORDER BY user_id ASC LIMIT $start_from, ".$results_per_page;
$result = $conn->query($sql) or die($conn->error);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Address</th><th>Phone Number</th><th> Action </th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["user_id"]. "</td><td>" . $row["user_first"]. " " . $row["user_last"].  "  <td>  " . $row["user_uid"]. " </td><td>" . $row["user_email"]. " </td><td>" . $row["user_address"]. " </td><td>" . $row["user_phone"]. "<td> <center><button onclick=\"location.href='EditUser.php'\"> Edit User </button>". "</td></tr>";
        
    }
    echo "</table>";
} else {
    echo "0 results";
}

?> 

 
 
 
<?php 
$sql = "SELECT COUNT(user_id) AS total FROM users";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_pages = ceil($row["total"] / $results_per_page); // calculate total pages with results
  
for ($i=1; $i<=$total_pages; $i++) {  // print links for all pages
            echo "<a href='../Admin/ManageUser.php?page=".$i."'";
            if ($i==$page)  echo " class='curPage'";
            echo ">".$i."</a> "; 
}; 
	
?>
