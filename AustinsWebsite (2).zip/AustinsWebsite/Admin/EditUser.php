<?php 
session_start();
?>
<?php include 'AdminHeader.php' ?>
<?php include '../Includes/dbh.inc.php' ?>


	<body bgcolor="grey">
		<div class="main">
<link type="text/css" rel="stylesheet" href="../styles/sheets.css" >

<?php 
$sql = "SELECT user_id,user_first,user_last,user_uid,user_email,user_address,user_phone FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $user_id = $row["user_id"];
        $user_first = $row["user_first"];
        $user_last = $row["user_last"];
        $user_uid = $row["user_uid"];
        $user_email = $row["user_email"];
        $user_address = $row["user_address"];
        $user_phone = $row["user_phone"];
        echo "<br/>
            <p style='font-size{


            20px;}'><center>  Edit User </h1> <br/><br/>
<style> 
input {
    width: 210px;
}
</style>

            <form class='signup-form' action='../AdminDbh/updateuser.admin.php' method='POST'>
            Id: <input type='text' name='user_id' value='$user_id' readonly='readonly'><br/>
        First Name: <input type='text' name='Newfirst' value='$user_first'><br/>
        Last Name: <input type='text' name='last' value='$user_last'><br/>
        Username: <input type='text' name='uid' value='$user_uid'><br/>
        Email: <input type='text' name='email' value='$user_email'><br/>
        Address: <input type='text' name='address' value='$user_address'><br/>
        Phone Number: <input type='text' name='phone' value='$user_phone'><br/><br/>

        <button type='submit' name='submit'> Save </button>

        </form>

        ";
        exit();
        
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?> 
