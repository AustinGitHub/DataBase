<?php 
session_start();
?>
<body bgcolor="grey">
	<div style="display: flex;justify-content: center;align-items:center;">

		<?php 
					
						if (isset($_SESSION['u_id'])) {
							echo '<?php include "AdminHeader.php"; ?>


						';
					
					
					} ?>
					

<form action="../AdminDbh/login.admin.php" method="POST" >
	<input type="text" placeholder="username" name="uid"><br> <br/> 
	<input type="password" placeholder="password" name="pwd"><br/> <br/> 
	<center> <button type="submit" name="submit"> Log in </button>
</form>
		
</div>

</html>