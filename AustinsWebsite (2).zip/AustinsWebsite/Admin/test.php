 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <input type="checkbox" id="change1" class="check"/> </td>


<script>
$(document).ready(function(){
$(":checkbox").click(function () {

if($("input[id^='change1']:checkbox:checked").length>0)
{
    $("#change").removeAttr('style');
}else
{
    $("#change").css({"display":"none"});
}




    });
});
</script>

<div id="change" style="display: none">
<select>
      <option value='Normal Game'> Normal Game </option>
      <option value='PlaceHolder'> PlaceHolder </option>
</select>
</div>