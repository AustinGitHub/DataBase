<?php 
session_start();
?>
<?php include 'AdminHeader.php' ?>


<link rel="stylesheet" href="../styles/bootstrap.min.css">


<link type="text/css" rel="stylesheet" href="../styles/creategame.css" >

<?php 
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "games";
    $conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);



$button = $_POST['button'];


$sql = "SELECT Id,Dates,GameType,SubType,GameName,FeeType,EntryFee,MinPlayers,MaxPlayers,MaxEntries,PrizeDetails,GameType2 FROM games WHERE Id = $button";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

  
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $Id = $row["Id"];
        $Dates = $row["Dates"];
        $GameType = $row["GameType"];
        $SubType = $row["SubType"];
        $GameName = $row["GameName"];
        $FeeType = $row["FeeType"];
        $EntryFee = $row["EntryFee"];
        $MinPlayers = $row["MinPlayers"];
        $MaxPlayers = $row["MaxPlayers"];
        $MaxEntries = $row["MaxEntries"];
        $PrizeDetails = $row["PrizeDetails"];
        $GameType2 = $row["GameType2"];

       
echo "<p value='$GameType2'></p>";
        echo "<br/>
          <h1><center>  Edit Game </h1> <br/><br/>

<body bgcolor='grey'>
        <div class='main'>
            <form action='../AdminDbh/UpdateGame.admin.php' method='POST'>
           
Game Id: <input type='text' name='id' value='$Id' readonly /> <br/><br/>
Date: <input type='date' name='dates' value='$Dates' /><br/>

    Game Type <br/>
    <input type='text'  value='$GameType2' readonly>


"; ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <input type="checkbox" id="change1" class="check"/> </td>


<script>
$(document).ready(function(){
$(":checkbox").click(function () {

if($("input[id^='change1']:checkbox:checked").length>0)
{
    $("#change").removeAttr('style');
}else
{
    $("#change").css({"display":"none"});
}




    });
});
</script>

<div id="change" style="display: none">
<select name="GameType2">
      <option value='Normal Game'> Normal Game </option>
      <option value='PlaceHolder'> PlaceHolder </option>
</select>

<?php 
echo "

</div>


    <br/>
 <br/> <br/>




<div id='one'>
  <div class='one'>
Type of Game <br/>
<select name='GameType' value='$GameType'>
  <option> Daily Game </option>

</select>
</div>
</div>

<div id='two'>
<div class='two'>
Sub Type of Game <br/>
<select name='SubType' value='$SubType'> 
  <option> Live Selector </option>
  <option> Locked </option>
</select>
</div>
</div>

<br/><br/>
<div id='three'>
  <div class='three'> 
Name of Contest <br/> 
<input type='text' name='NewGameName' value='$GameName' placeholder='Name of Contest' required><br/>
</div>
</div>

<div id='four'> 
  <div class='four'>
Fee Type <br/>
<select name='FeeType' value='$FeeType'>
  <option>Dollars</option>
</select>
</div>
</div>

<div id='five'> 
  <div class='five'>
Entry Fee <br/>
<input type='text' name='EntryFee' value='$EntryFee' required><br/>
</div>
</div>

<br/><br/>
<div id='six'>
  <div class='six'> 
# of Players (minimum and maximum) <br/>
<input type='text' name='MinPlayers' value='$MinPlayers' placeholder='Minimum Players' required> <input type='text' name='MaxPlayers' placeholder='Maximum Players' value='$MaxPlayers' required> <br/>
</div>
</div>

<div id='seven'> 
  <div class='seven'> 
Max Entries Per Player <br/>
<input type='text' name='MaxEntries' placeholder='Max entries per player' value='$MaxEntries' required> <br/>
</div>
</div>

<br/><br/>
<div id='eight'> 
  <div class='eight'> 
Detailed Prize Information <br/>
<textarea class='eight' style='width: 500px;height:200px;' name='DetailedPrize' value='$PrizeDetails'></textarea> <br/>
</div>
</div>




<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<div id='ten'>
  <div class='ten'>
<button name='submit1'> Update Game </button>
</div>
</div>

        </form>

        ";


        
        exit();
        
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?> 
